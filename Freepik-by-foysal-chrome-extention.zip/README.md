# Freepik Image Donwlaoder by Foysal


## How to install

1. Clone this repo `git clone https://github.com/notpewds/freepik-by-foysal-chrome-extention`
2. Open the Chrome browser and go to `chrome://extensions`.  

A Chrome extension can also be used in Brave and Ms Edge. If you are using one of those, go to `brave://extensions` and `edge://extensions` respectively.

3. Turn on the developer mode.
4. Click on the `load unpacked` and select the cloned repository.

